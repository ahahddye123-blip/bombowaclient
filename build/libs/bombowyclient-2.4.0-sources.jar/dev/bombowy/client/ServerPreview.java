package dev.bombowy.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_420;
import net.minecraft.class_422;
import net.minecraft.class_437;

public final class ServerPreview {
    private ServerPreview() {}

    private static String lastText = "";
    private static long lastChange = 0;
    private static String requested = "";
    private static volatile ServerPing.Result result = null;

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof class_420 || screen instanceof class_422) {
                lastText = "";
                requested = "";
                result = null;
                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) -> render(s, ctx));
            }
        });
    }

    private static void render(class_437 screen, class_332 ctx) {
        if (!Modules.isOn("quickjoin")) return;

        class_342 field = null;
        for (Object child : screen.method_25396()) {
            if (child instanceof class_342 tf) field = tf;
        }
        if (field == null) return;

        String text = field.method_1882().trim();
        long now = System.currentTimeMillis();
        if (!text.equals(lastText)) {
            lastText = text;
            lastChange = now;
            result = null;
        }
        if (!text.isEmpty() && !text.equals(requested) && now - lastChange > 600) {
            requested = text;
            final String target = text;
            Thread t = new Thread(() -> {
                ServerPing.Result r = ServerPing.ping(target);
                if (target.equals(requested)) result = r;
            }, "BombowyClient-ping");
            t.setDaemon(true);
            t.start();
        }
        if (text.isEmpty()) return;

        class_310 client = class_310.method_1551();
        class_327 tr = client.field_1772;
        ServerPing.Result r = result;

        String line1, line2 = "";
        int color1;
        if (r == null) { line1 = "Sprawdzam serwer..."; color1 = 0xFFB0B3C2; }
        else if (!r.ok) { line1 = "Serwer nie odpowiada"; color1 = 0xFFFF6666; }
        else {
            line1 = "Online: " + r.online + "/" + r.max
                    + (r.ms >= 0 ? "   Ping: " + r.ms + " ms" : "")
                    + (r.version.isEmpty() ? "" : "   " + r.version);
            line2 = r.motd;
            color1 = 0xFFFF9447;
        }

        int w = Math.min(screen.field_22789 - 20, 300), h = 30, x = (screen.field_22789 - w) / 2, y = screen.field_22790 - h - 4;
        ctx.method_25294(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF3A271E);
        ctx.method_25294(x, y, x + w, y + h, 0xE6121318);
        ctx.method_51433(tr, tr.method_27523(line1, w - 12), x + 6, y + 5, color1, false);
        if (!line2.isEmpty()) ctx.method_51433(tr, tr.method_27523(line2, w - 12), x + 6, y + 17, 0xFFB0B3C2, false);
    }
}
