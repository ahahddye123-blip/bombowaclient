package dev.bombowy.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class BombowyClient implements ClientModInitializer {
    public static class_304 openKey;
    private static boolean ownsNightVision = false;
    private static long lastGravePressMs = 0L;

    @Override
    public void onInitializeClient() {
        BombowyConfig.load();

        openKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.bombowyclient.open",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_GRAVE_ACCENT,
                "key.categories.bombowyclient"));

        BombowyRender.register();
        BombowyHud.register();
        KillEffects.register();
        ServerPreview.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.method_1436()) {
                long now = System.currentTimeMillis();
                long delta = now - lastGravePressMs;
                lastGravePressMs = now;

                if (delta > 0 && delta <= 420L) {
                    if (client.field_1755 == null || client.field_1755 instanceof MenuScreen) {
                        client.method_1507(new HudEditorScreen(null));
                    }
                } else {
                    if (client.field_1755 == null) {
                        BombowyExtras.playUiClick(client, 1.15f);
                        client.method_1507(new MenuScreen());
                    }
                }
            }
            tickBrightness(client);
            BombowyExtras.tick(client);
            BombowyHud.tick(client);
        });
    }

    private static void tickBrightness(class_310 client) {
        if (client.field_1724 == null) {
            ownsNightVision = false;
            return;
        }
        if (Modules.isOn("brightness")) {
            class_1293 cur = client.field_1724.method_6112(class_1294.field_5925);
            if (cur == null || !cur.method_48559()) {
                client.field_1724.method_6092(new class_1293(
                        class_1294.field_5925, class_1293.field_42106, 0, false, false, false));
            }
            ownsNightVision = true;
        } else if (ownsNightVision) {
            client.field_1724.method_6016(class_1294.field_5925);
            ownsNightVision = false;
        }
    }
}
