package dev.bombowy.client;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import org.joml.Matrix4f;

import java.util.Optional;

public final class BombowyRender {
    private BombowyRender() {}

    public static final class_2960 BOMB_TAG_TEX = class_2960.method_60655("bombowyclient", "textures/bomb_tag.png");

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(BombowyRender::onAfterEntities);
    }

    private static void onAfterEntities(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) return;

        boolean hitboxes = Modules.isOn("hitboxes");
        boolean drawOwnTag = !client.field_1690.method_31044().method_31034()
                && BombowyExtras.hasBombModTag(client.field_1724.method_7334().getName());
        if (!hitboxes && !drawOwnTag) return;

        class_4587 matrices = context.matrixStack();
        if (matrices == null) return;
        class_4184 camera = context.camera();
        class_243 cam = camera.method_19326();
        float td = client.method_61966().method_60637(false);
        class_4597.class_4598 immediate = client.method_22940().method_23000();

        if (hitboxes) {
            BombowyConfig cfg = BombowyConfig.get();
            class_4588 lines = immediate.getBuffer(class_1921.method_23594());
            class_243 eye = client.field_1724.method_5836(td);
            class_243 look = client.field_1724.method_5828(td);
            double reach = Math.max(1.0, cfg.hitboxReach);

            class_243 maxEnd = eye.method_1019(look.method_1021(reach));
            class_3965 blockHit = client.field_1687.method_17742(new class_3959(
                    eye, maxEnd, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, client.field_1724));
            double effectiveReach = reach;
            if (blockHit != null && blockHit.method_17783() != class_239.class_240.field_1333) {
                effectiveReach = blockHit.method_17784().method_1022(eye);
            }

            class_1297 aimedEntity = null;
            if (client.field_1765 instanceof class_3966 ehr && ehr.method_17782() instanceof class_742) {
                if (eye.method_1022(ehr.method_17784()) <= effectiveReach + 0.3) {
                    aimedEntity = ehr.method_17782();
                }
            }
            if (aimedEntity == null) {
                class_243 reachEnd = eye.method_1019(look.method_1021(effectiveReach));
                class_238 searchBox = client.field_1724.method_5829().method_18804(look.method_1021(effectiveReach)).method_1014(1.0);
                class_3966 rayHit = class_1675.method_18075(
                        client.field_1724, eye, reachEnd, searchBox,
                        e -> e instanceof class_742 && !e.method_7325() && e != client.field_1724,
                        effectiveReach * effectiveReach
                );
                if (rayHit != null) aimedEntity = rayHit.method_17782();
            }

            int aimRgb = cfg.hitboxAimColor & 0xFFFFFF;
            float aimR = ((aimRgb >> 16) & 0xFF) / 255.0f;
            float aimG = ((aimRgb >> 8) & 0xFF) / 255.0f;
            float aimB = (aimRgb & 0xFF) / 255.0f;

            int idleRgb = cfg.hitboxIdleColor & 0xFFFFFF;
            float idleR = ((idleRgb >> 16) & 0xFF) / 255.0f;
            float idleG = ((idleRgb >> 8) & 0xFF) / 255.0f;
            float idleB = (idleRgb & 0xFF) / 255.0f;

            matrices.method_22903();
            matrices.method_22904(-cam.field_1352, -cam.field_1351, -cam.field_1350);
            for (class_742 p : client.field_1687.method_18456()) {
                if (p == client.field_1724 || p.method_7325()) continue;

                double ix = class_3532.method_16436(td, p.field_6014, p.method_23317());
                double iy = class_3532.method_16436(td, p.field_6036, p.method_23318());
                double iz = class_3532.method_16436(td, p.field_5969, p.method_23321());
                class_238 box = p.method_5829().method_989(ix - p.method_23317(), iy - p.method_23318(), iz - p.method_23321());

                class_243 end = eye.method_1019(look.method_1021(effectiveReach));
                Optional<class_243> hitPos = box.method_1014(p.method_5871()).method_992(eye, end);
                boolean isAiming = (p == aimedEntity) || hitPos.isPresent();

                if (!isAiming && !cfg.hitboxShowAll) continue;

                if (isAiming) bombowyDrawBox(matrices, lines, box, aimR, aimG, aimB, 1.0f);
                else bombowyDrawBox(matrices, lines, box, idleR, idleG, idleB, 0.9f);
            }
            matrices.method_22909();
            immediate.method_22994(class_1921.method_23594());
        }

        if (drawOwnTag) {
            String rawName = client.field_1724.method_7334().getName();
            class_2561 name = BombowyExtras.formatPlayerText(client.field_1724.method_5476(), rawName);
            class_243 pos = client.field_1724.method_30950(td);
            class_327 tr = client.field_1772;

            matrices.method_22903();
            matrices.method_22904(pos.field_1352 - cam.field_1352, pos.field_1351 + client.field_1724.method_17682() + 0.52 - cam.field_1351, pos.field_1350 - cam.field_1350);
            matrices.method_22907(camera.method_23767());
            matrices.method_22905(0.025f, -0.025f, 0.025f);
            Matrix4f matrix = matrices.method_23760().method_23761();
            float x = -tr.method_27525(name) / 2.0f;
            class_332 dc = new class_332(client, immediate);
            dc.method_25290(class_1921::method_62277, BOMB_TAG_TEX, (int) x - 13, -2, 0f, 0f, 11, 11, 11, 11);
            tr.method_27522(name, x, 0.0f, 0xFFFFFFFF, false, matrix, immediate,
                    class_327.class_6415.field_33993, 0, 0xF000F0);
            immediate.method_22993();
            matrices.method_22909();
        }
    }

    private static void bombowyDrawBox(class_4587 matrices, class_4588 lines, class_238 box,
                                         float r, float g, float b, float a) {
        try {
            Class<?> vr = Class.forName("net.minecraft.client.render.VertexRendering");
            for (var m : vr.getMethods()) {
                if (m.getName().equals("drawBox") && m.getParameterCount() == 7) {
                    m.invoke(null, matrices, lines, box, r, g, b, a);
                    return;
                }
            }
        } catch (Throwable ignored) {}
        var entry = matrices.method_23760();
        double x1 = box.field_1323, y1 = box.field_1322, z1 = box.field_1321;
        double x2 = box.field_1320, y2 = box.field_1325, z2 = box.field_1324;
        double[][] pts = {
            {x1, y1, z1}, {x2, y1, z1}, {x2, y1, z2}, {x1, y1, z2},
            {x1, y2, z1}, {x2, y2, z1}, {x2, y2, z2}, {x1, y2, z2}
        };
        int[][] edges = {
            {0,1},{1,2},{2,3},{3,0},
            {4,5},{5,6},{6,7},{7,4},
            {0,4},{1,5},{2,6},{3,7}
        };
        for (int[] e : edges) {
            double[] p1 = pts[e[0]], p2 = pts[e[1]];
            float dx = (float)(p2[0] - p1[0]), dy = (float)(p2[1] - p1[1]), dz = (float)(p2[2] - p1[2]);
            float len = (float)Math.sqrt(dx*dx + dy*dy + dz*dz);
            float nx = len > 0 ? dx/len : 0f, ny = len > 0 ? dy/len : 1f, nz = len > 0 ? dz/len : 0f;
            lines.method_56824(entry, (float)p1[0], (float)p1[1], (float)p1[2]).method_22915(r, g, b, a).method_60831(entry, nx, ny, nz);
            lines.method_56824(entry, (float)p2[0], (float)p2[1], (float)p2[2]).method_22915(r, g, b, a).method_60831(entry, nx, ny, nz);
        }
    }
}
