package dev.bombowy.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1792;
import net.minecraft.class_1796;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_9779;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class BombowyHud {
    private BombowyHud() {}

    private static final Map<class_1792, Long> cooldownStartTime = new LinkedHashMap<>();
    private static final Map<class_1792, Float> lastSeenProgress = new LinkedHashMap<>();

    public static final class CooldownEntry {
        public final class_1799 stack;
        public final float progress;
        public final float secondsLeft;

        public CooldownEntry(class_1799 stack, float progress, float secondsLeft) {
            this.stack = stack;
            this.progress = progress;
            this.secondsLeft = secondsLeft;
        }
    }

    public static void register() {
        HudRenderCallback.EVENT.register(BombowyHud::onRenderHud);
    }

    public static void tick(class_310 client) {
        if (client.field_1724 == null) {
            cooldownStartTime.clear();
            lastSeenProgress.clear();
            return;
        }
        class_1796 mgr = client.field_1724.method_7357();
        long now = System.currentTimeMillis();

        List<class_1792> watched = List.of(
                class_1802.field_8634, class_1802.field_8255, class_1802.field_8233,
                class_1802.field_8463, class_1802.field_8367, class_1802.field_49098
        );

        for (class_1792 item : watched) {
            class_1799 dummy = new class_1799(item);
            if (mgr.method_7904(dummy)) {
                float p = mgr.method_7905(dummy, 0f);
                Float prev = lastSeenProgress.get(item);
                if (!cooldownStartTime.containsKey(item) || (prev != null && p > prev + 0.05f)) {
                    cooldownStartTime.put(item, now);
                }
                lastSeenProgress.put(item, p);
            } else {
                cooldownStartTime.remove(item);
                lastSeenProgress.remove(item);
            }
        }
    }

    private static void onRenderHud(class_332 ctx, class_9779 tickCounter) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1690.field_1842) return;
        if (client.field_1755 instanceof HudEditorScreen) return;

        float td = tickCounter.method_60637(false);
        BombowyConfig cfg = BombowyConfig.get();

        if (Modules.isOn("fpshud") || cfg.hudFps.enabled) renderFps(ctx, client, cfg.hudFps, false);
        if (Modules.isOn("statshud") || cfg.hudStats.enabled) renderStats(ctx, client, cfg.hudStats, false);
        if (Modules.isOn("inventoryhud") || cfg.hudInventory.enabled) renderInventory(ctx, client, cfg.hudInventory, false);
        if (Modules.isOn("cooldowns") || cfg.hudCooldowns.enabled) renderCooldowns(ctx, client, cfg.hudCooldowns, td, false);
    }

    public static int resolveTextColor(BombowyConfig.HudElement el) {
        return 0xFFFFFFFF;
    }

    public static int resolveBgColor(BombowyConfig.HudElement el) {
        int alpha = class_3532.method_15340((int) (el.bgOpacity * 160.0f), 0, 160);
        return (alpha << 24) | 0x101010;
    }

    public static int[] fpsSize(class_327 tr, class_310 client) {
        String txt = client.method_47599() + " FPS";
        return new int[]{tr.method_1727(txt) + 6, 12};
    }

    public static void renderFps(class_332 ctx, class_310 client, BombowyConfig.HudElement el, boolean preview) {
        class_327 tr = client.field_1772;
        String txt = client.method_47599() + " FPS";
        int[] sz = fpsSize(tr, client);

        ctx.method_51448().method_22903();
        ctx.method_51448().method_46416(el.x, el.y, 0);
        ctx.method_51448().method_22905(el.scale, el.scale, 1.0f);

        int bg = resolveBgColor(el);
        if ((bg >>> 24) > 0) ctx.method_25294(0, 0, sz[0], sz[1], bg);
        ctx.method_51433(tr, txt, 2, 2, resolveTextColor(el), true);
        ctx.method_51448().method_22909();
    }

    public static String statsText(class_310 client, boolean preview) {
        BombowyConfig cfg = BombowyConfig.get();
        List<String> parts = new ArrayList<>();
        if (cfg.showCps) {
            int l = BombowyExtras.getLeftCps();
            int r = BombowyExtras.getRightCps();
            parts.add((preview && l == 0 && r == 0) ? "12 / 6 CPS" : l + " / " + r + " CPS");
        }
        if (cfg.showPing) {
            int ping = BombowyExtras.getPing(client);
            parts.add((preview && ping == 0) ? "24 ms" : ping + " ms");
        }
        if (parts.isEmpty()) return "0 CPS | 0 ms";
        return String.join(" | ", parts);
    }

    public static int[] statsSize(class_327 tr, class_310 client, boolean preview) {
        String txt = statsText(client, preview);
        return new int[]{tr.method_1727(txt) + 6, 12};
    }

    public static void renderStats(class_332 ctx, class_310 client, BombowyConfig.HudElement el, boolean preview) {
        class_327 tr = client.field_1772;
        String txt = statsText(client, preview);
        int[] sz = statsSize(tr, client, preview);

        ctx.method_51448().method_22903();
        ctx.method_51448().method_46416(el.x, el.y, 0);
        ctx.method_51448().method_22905(el.scale, el.scale, 1.0f);

        int bg = resolveBgColor(el);
        if ((bg >>> 24) > 0) ctx.method_25294(0, 0, sz[0], sz[1], bg);
        ctx.method_51433(tr, txt, 2, 2, resolveTextColor(el), true);
        ctx.method_51448().method_22909();
    }

    public static int[] inventorySize(BombowyConfig cfg) {
        int slot = cfg.invCompact ? 16 : 18;
        int rows = cfg.invShowHotbar ? 4 : 3;
        return new int[]{9 * slot + 2, rows * slot + 2 + (cfg.invShowHotbar ? 2 : 0)};
    }

    public static void renderInventory(class_332 ctx, class_310 client, BombowyConfig.HudElement el, boolean preview) {
        BombowyConfig cfg = BombowyConfig.get();
        int slot = cfg.invCompact ? 16 : 18;
        int[] sz = inventorySize(cfg);

        ctx.method_51448().method_22903();
        ctx.method_51448().method_46416(el.x, el.y, 0);
        ctx.method_51448().method_22905(el.scale, el.scale, 1.0f);

        int bg = resolveBgColor(el);
        if ((bg >>> 24) > 0) ctx.method_25294(0, 0, sz[0], sz[1], bg);

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                int idx = 9 + row * 9 + col;
                int sx = 1 + col * slot;
                int sy = 1 + row * slot;
                ctx.method_25294(sx, sy, sx + 16, sy + 16, 0x33000000);

                class_1799 stack = client.field_1724 != null ? client.field_1724.method_31548().method_5438(idx) : class_1799.field_8037;
                if (preview && stack.method_7960() && row == 0 && col < 3) {
                    stack = col == 0 ? new class_1799(class_1802.field_8634, 16)
                            : col == 1 ? new class_1799(class_1802.field_8463, 8)
                            : new class_1799(class_1802.field_8288, 1);
                }
                if (!stack.method_7960()) {
                    ctx.method_51427(stack, sx, sy);
                    ctx.method_51431(client.field_1772, stack, sx, sy);
                }
            }
        }

        if (cfg.invShowHotbar) {
            int hy = 1 + 3 * slot + 2;
            for (int col = 0; col < 9; col++) {
                int sx = 1 + col * slot;
                ctx.method_25294(sx, hy, sx + 16, hy + 16, 0x33000000);
                class_1799 stack = client.field_1724 != null ? client.field_1724.method_31548().method_5438(col) : class_1799.field_8037;
                if (!stack.method_7960()) {
                    ctx.method_51427(stack, sx, hy);
                    ctx.method_51431(client.field_1772, stack, sx, hy);
                }
            }
        }

        ctx.method_51448().method_22909();
    }

    public static List<CooldownEntry> collectCooldowns(class_310 client, float td, boolean preview) {
        List<CooldownEntry> list = new ArrayList<>();
        BombowyConfig cfg = BombowyConfig.get();

        if (client.field_1724 != null) {
            class_1796 mgr = client.field_1724.method_7357();
            List<class_1792> candidates = new ArrayList<>();

            if (cfg.cdPearl) candidates.add(class_1802.field_8634);
            if (cfg.cdShield) candidates.add(class_1802.field_8255);
            if (cfg.cdChorus) candidates.add(class_1802.field_8233);
            if (cfg.cdGoldenApple) {
                candidates.add(class_1802.field_8463);
                candidates.add(class_1802.field_8367);
            }
            if (cfg.cdWindCharge) candidates.add(class_1802.field_49098);

            if (cfg.cdOther) {
                for (int i = 0; i < client.field_1724.method_31548().method_5439(); i++) {
                    class_1799 st = client.field_1724.method_31548().method_5438(i);
                    if (!st.method_7960() && !candidates.contains(st.method_7909())) {
                        candidates.add(st.method_7909());
                    }
                }
            }

            for (class_1792 item : candidates) {
                class_1799 dummy = new class_1799(item);
                if (mgr.method_7904(dummy)) {
                    float prog = mgr.method_7905(dummy, td);
                    if (prog > 0.001f) {
                        list.add(new CooldownEntry(dummy, prog, estimateSecondsLeft(item, prog)));
                    }
                }
            }
        }

        if (preview && list.isEmpty()) {
            list.add(new CooldownEntry(new class_1799(class_1802.field_8634), 0.65f, 0.7f));
            list.add(new CooldownEntry(new class_1799(class_1802.field_8255), 0.48f, 2.4f));
        }
        return list;
    }

    private static float estimateSecondsLeft(class_1792 item, float progress) {
        Long started = cooldownStartTime.get(item);
        if (started != null && progress > 0.01f && progress < 0.99f) {
            float elapsedSec = (System.currentTimeMillis() - started) / 1000.0f;
            float totalEst = elapsedSec / Math.max(0.05f, (1.0f - progress));
            if (totalEst > 0.2f && totalEst < 60.0f) {
                return Math.max(0.1f, totalEst * progress);
            }
        }
        if (item == class_1802.field_8255) return 5.0f * progress;
        if (item == class_1802.field_8634) return 1.0f * progress;
        if (item == class_1802.field_8233) return 1.0f * progress;
        if (item == class_1802.field_49098) return 0.5f * progress;
        return 3.0f * progress;
    }

    public static int[] cooldownsSize(class_310 client, float td, boolean preview) {
        List<CooldownEntry> entries = collectCooldowns(client, td, preview);
        int rows = Math.max(1, entries.size());
        return new int[]{72, rows * 17 + 2};
    }

    public static void renderCooldowns(class_332 ctx, class_310 client, BombowyConfig.HudElement el, float td, boolean preview) {
        List<CooldownEntry> entries = collectCooldowns(client, td, preview);
        if (entries.isEmpty()) return;

        class_327 tr = client.field_1772;
        int w = 72;
        int h = entries.size() * 17 + 2;

        ctx.method_51448().method_22903();
        ctx.method_51448().method_46416(el.x, el.y, 0);
        ctx.method_51448().method_22905(el.scale, el.scale, 1.0f);

        int bg = resolveBgColor(el);
        if ((bg >>> 24) > 0) ctx.method_25294(0, 0, w, h, bg);

        for (int i = 0; i < entries.size(); i++) {
            CooldownEntry e = entries.get(i);
            int ry = 1 + i * 17;
            ctx.method_51427(e.stack, 1, ry);
            String timeTxt = String.format("%.1fs", Math.max(0.1f, e.secondsLeft));
            ctx.method_51433(tr, timeTxt, 21, ry + 4, 0xFFFFFFFF, true);
        }

        ctx.method_51448().method_22909();
    }
}
