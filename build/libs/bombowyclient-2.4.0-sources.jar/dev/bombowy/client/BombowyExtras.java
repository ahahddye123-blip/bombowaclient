package dev.bombowy.client;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_5250;
import net.minecraft.class_640;

public final class BombowyExtras {
    private BombowyExtras() {}

    private static final Deque<Long> leftClicks = new ArrayDeque<>();
    private static final Deque<Long> rightClicks = new ArrayDeque<>();
    private static final Set<String> knownBombUsers = new HashSet<>();
    private static final Set<Integer> triggeredDeaths = new HashSet<>();

    public static void recordClick(int button) {
        long now = System.currentTimeMillis();
        if (button == 0) leftClicks.addLast(now);
        else if (button == 1) rightClicks.addLast(now);
        prune(now);
    }

    public static void playUiClick(class_310 client, float pitch) {
        BombowyConfig cfg = BombowyConfig.get();
        if (!cfg.uiSounds || client == null || client.field_1724 == null) return;
        client.field_1724.method_5783(class_3417.field_15015.comp_349(), cfg.uiSoundVolume, pitch);
    }

    public static void tick(class_310 client) {
        long now = System.currentTimeMillis();
        prune(now);

        if (client.field_1687 == null || client.field_1724 == null) {
            triggeredDeaths.clear();
            return;
        }

        String selfName = client.field_1724.method_7334().getName();
        if (selfName != null && !selfName.isBlank()) {
            knownBombUsers.add(selfName.toLowerCase(Locale.ROOT));
        }

        if (Modules.isOn("autosprint") && client.field_1690.field_1894.method_1434() && !client.field_1724.method_5715()) {
            if (!client.field_1724.method_5624()) {
                client.field_1724.method_5728(true);
            }
        }

        if (Modules.isOn("killeffects")) {
            triggeredDeaths.removeIf(id -> client.field_1687.method_8469(id) == null);
            for (class_1657 p : client.field_1687.method_18456()) {
                if (p == client.field_1724) continue;
                if ((p.method_29504() || p.method_6032() <= 0.0f) && p.method_5858(client.field_1724) <= 144.0) {
                    if (triggeredDeaths.add(p.method_5628())) {
                        KillEffects.spawnAt(p.method_23317(), p.method_23318() + 0.9, p.method_23321());
                    }
                }
            }
        }
    }

    private static void prune(long now) {
        while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000L) leftClicks.pollFirst();
        while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000L) rightClicks.pollFirst();
    }

    public static int getLeftCps() {
        prune(System.currentTimeMillis());
        return leftClicks.size();
    }

    public static int getRightCps() {
        prune(System.currentTimeMillis());
        return rightClicks.size();
    }

    public static int getPing(class_310 client) {
        if (client.method_1562() == null || client.field_1724 == null) return 0;
        class_640 entry = client.method_1562().method_2871(client.field_1724.method_5667());
        if (entry == null) {
            entry = client.method_1562().method_2874(client.field_1724.method_7334().getName());
        }
        return entry != null ? Math.max(0, entry.method_2959()) : 0;
    }

    public static boolean hasBombModTag(String playerName) {
        if (playerName == null || playerName.isBlank()) return false;
        BombowyConfig cfg = BombowyConfig.get();
        if (cfg.bombTagAllPlayers) return true;
        String lower = playerName.toLowerCase(Locale.ROOT);
        if (knownBombUsers.contains(lower)) return true;
        for (String extra : cfg.bombTagPlayers) {
            if (extra != null && extra.trim().equalsIgnoreCase(playerName.trim())) {
                return true;
            }
        }
        return false;
    }

    public static class_2561 formatPlayerText(class_2561 original, String rawPlayerName) {
        if (original == null || rawPlayerName == null || rawPlayerName.isBlank()) return original;
        if (!hasBombModTag(rawPlayerName)) return original;

        String full = original.getString();
        int idx = full.toLowerCase(Locale.ROOT).indexOf(rawPlayerName.toLowerCase(Locale.ROOT));
        class_5250 out = class_2561.method_43473();

        if (idx > 0) {
            String prefix = full.substring(0, idx);
            out.method_10852(class_2561.method_43470(prefix).method_10862(findStyleAt(original, 0)));
        }

        String actualNick = (idx >= 0) ? full.substring(idx, idx + rawPlayerName.length()) : rawPlayerName;
        out.method_10852(class_2561.method_43470("(💣) ").method_10862(class_2583.field_24360.method_10977(class_124.field_1074).method_10982(true)));
        out.method_10852(class_2561.method_43470(actualNick).method_10862(class_2583.field_24360.method_10977(class_124.field_1068)));

        if (idx >= 0 && idx + actualNick.length() < full.length()) {
            String suffix = full.substring(idx + actualNick.length());
            out.method_10852(class_2561.method_43470(suffix).method_10862(findStyleAt(original, idx + actualNick.length())));
        }

        return out;
    }

    private static class_2583 findStyleAt(class_2561 text, int targetIndex) {
        final int[] cursor = {0};
        final class_2583[] found = {class_2583.field_24360};
        text.method_27658((style, str) -> {
            int next = cursor[0] + str.length();
            if (targetIndex >= cursor[0] && targetIndex < next) {
                found[0] = style;
                return java.util.Optional.empty();
            }
            cursor[0] = next;
            return java.util.Optional.empty();
        }, class_2583.field_24360);
        return found[0];
    }
}
