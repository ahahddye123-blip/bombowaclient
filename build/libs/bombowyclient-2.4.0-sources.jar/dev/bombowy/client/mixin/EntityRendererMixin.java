package dev.bombowy.client.mixin;

import dev.bombowy.client.BombowyExtras;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_897.class)
public abstract class EntityRendererMixin {
    @Redirect(
            method = "renderLabelIfPresent",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/GameOptions;getTextBackgroundOpacity(F)F"),
            require = 0)
    private float bombowy$transparentNametags(class_315 options, float fallback) {
        return options.method_19343(fallback);
    }

    @ModifyVariable(method = "renderLabelIfPresent", at = @At("HEAD"), argsOnly = true, require = 0)
    private class_2561 bombowy$formatPlayerLabel(class_2561 text, class_1297 entity, class_2561 originalText, class_4587 matrices,
                                          class_4597 vertexConsumers, int light, float tickDelta) {
        if (entity instanceof class_1657 pe) {
            return BombowyExtras.formatPlayerText(text, pe.method_7334().getName());
        }
        return text;
    }
}
