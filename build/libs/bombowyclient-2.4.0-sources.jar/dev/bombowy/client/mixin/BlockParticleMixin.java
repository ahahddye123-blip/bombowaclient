package dev.bombowy.client.mixin;

import dev.bombowy.client.Modules;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_702;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_702.class)
public abstract class BlockParticleMixin {
    @Inject(method = "addBlockBreakParticles", at = @At("HEAD"), cancellable = true, require = 0)
    private void bombowy$noBlockBreakParticles(class_2338 pos, class_2680 state, CallbackInfo ci) {
        if (Modules.isOn("noparticles")) ci.cancel();
    }

    @Inject(method = "addBlockBreakingParticles", at = @At("HEAD"), cancellable = true, require = 0)
    private void bombowy$noBlockBreakingParticles(class_2338 pos, class_2350 direction, CallbackInfo ci) {
        if (Modules.isOn("noparticles")) ci.cancel();
    }
}
