package dev.bombowy.client.mixin;

import dev.bombowy.client.BombowyConfig;
import dev.bombowy.client.Modules;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4603.class)
public abstract class InGameOverlayRendererMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), require = 0)
    private static void bombowy$lowFireHead(class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
        if (Modules.isOn("cleanview") && BombowyConfig.get().lowFire) {
            matrices.method_22903();
            matrices.method_22904(0.0, -BombowyConfig.get().fireOffset, 0.0);
        }
    }

    @Inject(method = "renderFireOverlay", at = @At("RETURN"), require = 0)
    private static void bombowy$lowFireReturn(class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
        if (Modules.isOn("cleanview") && BombowyConfig.get().lowFire) {
            matrices.method_22909();
        }
    }
}
