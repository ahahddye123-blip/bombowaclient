package dev.bombowy.client.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.bombowy.client.BombowyConfig;
import dev.bombowy.client.Modules;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void bombowy$noVignette(class_332 context, class_1297 entity, CallbackInfo ci) {
        if (Modules.isOn("cleanview") && BombowyConfig.get().noVignette) {
            ci.cancel();
        }
    }

    @Inject(method = "render", at = @At("RETURN"), require = 0)
    private void bombowy$colorBoostOverlay(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (!Modules.isOn("colorboost")) return;
        class_310 client = class_310.method_1551();
        if (client.field_1755 != null) return;

        BombowyConfig cfg = BombowyConfig.get();
        int w = client.method_22683().method_4486();
        int h = client.method_22683().method_4502();

        int vibranceAlpha = (int) Math.min(20, Math.max(0, (cfg.colorVibrance - 1.0f) * 18.0f));
        if (vibranceAlpha > 0) {
            RenderSystem.enableBlend();
            context.method_25294(0, 0, w, h, (vibranceAlpha << 24) | 0xFF9E44);
        }

        int tintAlpha = (int) Math.min(60, Math.max(0, cfg.colorTintStrength * 180.0f));
        if (tintAlpha > 0) {
            context.method_25294(0, 0, w, h, (tintAlpha << 24) | (cfg.colorTintHex & 0xFFFFFF));
        }
    }
}
