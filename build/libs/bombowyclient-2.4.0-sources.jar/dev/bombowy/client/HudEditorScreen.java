package dev.bombowy.client;

import org.lwjgl.glfw.GLFW;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;

public class HudEditorScreen extends class_437 {
    private final class_437 parent;
    private enum Target { FPS, STATS, INVENTORY, COOLDOWNS }

    private Target dragging = null;
    private Target resizing = null;
    private double dragOffsetX, dragOffsetY;
    private double resizeStartX, resizeStartScale;
    private float openAnim = 0.0f;

    public HudEditorScreen(class_437 parent) {
        super(class_2561.method_43470("Edytor HUD"));
        this.parent = parent;
    }

    private BombowyConfig.HudElement getEl(Target t) {
        BombowyConfig cfg = BombowyConfig.get();
        return switch (t) {
            case FPS -> cfg.hudFps;
            case STATS -> cfg.hudStats;
            case INVENTORY -> cfg.hudInventory;
            case COOLDOWNS -> cfg.hudCooldowns;
        };
    }

    private String getModuleId(Target t) {
        return switch (t) {
            case FPS -> "fpshud";
            case STATS -> "statshud";
            case INVENTORY -> "inventoryhud";
            case COOLDOWNS -> "cooldowns";
        };
    }

    private int[] getBox(Target t) {
        BombowyConfig.HudElement el = getEl(t);
        int[] base = switch (t) {
            case FPS -> BombowyHud.fpsSize(this.field_22793, this.field_22787);
            case STATS -> BombowyHud.statsSize(this.field_22793, this.field_22787, true);
            case INVENTORY -> BombowyHud.inventorySize(BombowyConfig.get());
            case COOLDOWNS -> BombowyHud.cooldownsSize(this.field_22787, 0f, true);
        };
        int w = Math.max(24, (int) (base[0] * el.scale));
        int h = Math.max(14, (int) (base[1] * el.scale));
        return new int[]{(int) el.x, (int) el.y, w, h};
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {}

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        openAnim = class_3532.method_15363(openAnim + delta * 0.22f, 0.0f, 1.0f);
        float ease = 1.0f - (1.0f - openAnim) * (1.0f - openAnim);

        ctx.method_25294(0, 0, this.field_22789, this.field_22790, ((int) (0x68 * ease) << 24));
        ctx.method_25294(this.field_22789 / 2, 0, this.field_22789 / 2 + 1, this.field_22790, 0x26FF9E44);
        ctx.method_25294(0, this.field_22790 / 2, this.field_22789, this.field_22790 / 2 + 1, 0x26FF9E44);

        String info = "Edytor HUD — przeciągnij | róg = rozmiar | ⚙ = ustawienia | − = wyłącz";
        int iw = this.field_22793.method_1727(info) + 22;
        int ix = (this.field_22789 - iw) / 2;
        int iy = (int) (-24 + (8 + 24) * ease);
        ctx.method_25294(ix, iy, ix + iw, iy + 18, 0xE016171D);
        ctx.method_25294(ix, iy + 17, ix + iw, iy + 18, 0xFFFF7A2E);
        ctx.method_51433(this.field_22793, info, ix + 11, iy + 5, 0xFFF2F3F8, false);

        int bx = (this.field_22789 - 120) / 2, by = this.field_22790 - 28;
        boolean bHov = mx >= bx && mx <= bx + 120 && my >= by && my <= by + 20;
        ctx.method_25294(bx, by, bx + 120, by + 20, bHov ? 0xFFFF8C3B : 0xFFE06620);
        String backLbl = "Zapisz i wróć";
        ctx.method_51433(this.field_22793, backLbl, bx + (120 - this.field_22793.method_1727(backLbl)) / 2, by + 6, 0xFFFFFFFF, false);

        for (Target t : Target.values()) {
            BombowyConfig.HudElement el = getEl(t);
            if (!el.enabled) continue;

            if (t == Target.FPS) BombowyHud.renderFps(ctx, this.field_22787, el, true);
            if (t == Target.STATS) BombowyHud.renderStats(ctx, this.field_22787, el, true);
            if (t == Target.INVENTORY) BombowyHud.renderInventory(ctx, this.field_22787, el, true);
            if (t == Target.COOLDOWNS) BombowyHud.renderCooldowns(ctx, this.field_22787, el, 0f, true);

            int[] b = getBox(t);
            int x = b[0], y = b[1], w = b[2], h = b[3];
            int frameCol = 0xCCFF8A3D;
            ctx.method_25294(x - 1, y - 1, x + w + 1, y, frameCol);
            ctx.method_25294(x - 1, y + h, x + w + 1, y + h + 1, frameCol);
            ctx.method_25294(x - 1, y, x, y + h, frameCol);
            ctx.method_25294(x + w, y, x + w + 1, y + h, frameCol);

            int barY = Math.max(2, y - 14);
            int gearX = x + w - 26;
            boolean gHov = mx >= gearX && mx < gearX + 12 && my >= barY && my < barY + 12;
            ctx.method_25294(gearX, barY, gearX + 12, barY + 12, gHov ? 0xFF3A3C4A : 0xDD17181E);
            ctx.method_51433(this.field_22793, "⚙", gearX + 3, barY + 2, 0xFFFFFFFF, false);

            int minX = x + w - 12;
            boolean mHov = mx >= minX && mx < minX + 12 && my >= barY && my < barY + 12;
            ctx.method_25294(minX, barY, minX + 12, barY + 12, mHov ? 0xFFE04848 : 0xDD17181E);
            ctx.method_51433(this.field_22793, "-", minX + 4, barY + 2, 0xFFFFFFFF, false);

            int rx = x + w - 6, ry = y + h - 6;
            boolean rHov = mx >= rx - 2 && mx <= x + w + 2 && my >= ry - 2 && my <= y + h + 2;
            ctx.method_25294(rx, ry, x + w + 1, y + h + 1, rHov ? 0xFFFFFFFF : 0xFFFF8A3D);
        }
    }

    @Override
    public boolean method_25402(double mx, double my, int button) {
        if (button != 0) return super.method_25402(mx, my, button);

        int bx = (this.field_22789 - 120) / 2, by = this.field_22790 - 28;
        if (mx >= bx && mx <= bx + 120 && my >= by && my <= by + 20) {
            BombowyExtras.playUiClick(this.field_22787, 1.0f);
            BombowyConfig.save();
            this.field_22787.method_1507(parent);
            return true;
        }

        for (Target t : List.of(Target.COOLDOWNS, Target.INVENTORY, Target.STATS, Target.FPS)) {
            BombowyConfig.HudElement el = getEl(t);
            if (!el.enabled) continue;

            int[] b = getBox(t);
            int x = b[0], y = b[1], w = b[2], h = b[3];
            int barY = Math.max(2, y - 14);

            int gearX = x + w - 26;
            if (mx >= gearX && mx < gearX + 12 && my >= barY && my < barY + 12) {
                Modules.Module mod = Modules.byId(getModuleId(t));
                if (mod != null) {
                    BombowyExtras.playUiClick(this.field_22787, 1.25f);
                    this.field_22787.method_1507(new ModuleSettingsScreen(this, mod));
                }
                return true;
            }

            int minX = x + w - 12;
            if (mx >= minX && mx < minX + 12 && my >= barY && my < barY + 12) {
                Modules.Module mod = Modules.byId(getModuleId(t));
                if (mod != null) mod.setOn(false);
                el.enabled = false;
                BombowyExtras.playUiClick(this.field_22787, 0.9f);
                BombowyConfig.save();
                return true;
            }

            int rx = x + w - 6, ry = y + h - 6;
            if (mx >= rx - 2 && mx <= x + w + 2 && my >= ry - 2 && my <= y + h + 2) {
                resizing = t;
                resizeStartX = mx;
                resizeStartScale = el.scale;
                return true;
            }

            if (mx >= x && mx <= x + w && my >= y && my <= y + h) {
                dragging = t;
                dragOffsetX = mx - el.x;
                dragOffsetY = my - el.y;
                return true;
            }
        }
        return super.method_25402(mx, my, button);
    }

    @Override
    public boolean method_25403(double mx, double my, int button, double deltaX, double deltaY) {
        if (dragging != null) {
            BombowyConfig.HudElement el = getEl(dragging);
            el.x = class_3532.method_15363((float) (mx - dragOffsetX), 0, Math.max(10, this.field_22789 - 20));
            el.y = class_3532.method_15363((float) (my - dragOffsetY), 0, Math.max(10, this.field_22790 - 14));
            return true;
        }
        if (resizing != null) {
            BombowyConfig.HudElement el = getEl(resizing);
            el.scale = class_3532.method_15363((float) (resizeStartScale + (mx - resizeStartX) / 80.0), 0.5f, 2.5f);
            return true;
        }
        return super.method_25403(mx, my, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(double mx, double my, int button) {
        if (dragging != null || resizing != null) {
            dragging = null;
            resizing = null;
            BombowyConfig.save();
            return true;
        }
        return super.method_25406(mx, my, button);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_GRAVE_ACCENT) {
            BombowyConfig.save();
            this.field_22787.method_1507(parent);
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25421() { return false; }
}
