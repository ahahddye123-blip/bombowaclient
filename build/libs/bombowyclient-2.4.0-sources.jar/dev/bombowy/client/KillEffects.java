package dev.bombowy.client;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public final class KillEffects {
    private KillEffects() {}

    public static final String[] EFFECT_NAMES = {
            "Dolary ($)",
            "Rekin z nieba",
            "Piorun",
            "Eksplozja iskier",
            "Złote monety"
    };

    private static final class ActiveEffect {
        final int type;
        final double x, y, z;
        final long startMs;
        final long durationMs;
        final List<BillParticle> bills = new ArrayList<>();
        final List<SparkParticle> sparks = new ArrayList<>();

        ActiveEffect(int type, double x, double y, double z, long now, Random rng) {
            this.type = type;
            this.x = x;
            this.y = y;
            this.z = z;
            this.startMs = now;
            this.durationMs = (type == 1) ? 1450L : (type == 2) ? 950L : 1550L;

            if (type == 0 || type == 4) {
                int count = 14;
                for (int i = 0; i < count; i++) {
                    double ang = (Math.PI * 2.0 * i) / count + rng.nextDouble() * 0.25;
                    double spd = 0.045 + rng.nextDouble() * 0.055;
                    bills.add(new BillParticle(
                            Math.cos(ang) * spd,
                            0.055 + rng.nextDouble() * 0.055,
                            Math.sin(ang) * spd,
                            rng.nextFloat() * 360f,
                            (rng.nextFloat() - 0.5f) * 8f
                    ));
                }
            }
            for (int i = 0; i < 18; i++) {
                double ang = rng.nextDouble() * Math.PI * 2.0;
                double spd = 0.03 + rng.nextDouble() * 0.08;
                sparks.add(new SparkParticle(
                        Math.cos(ang) * spd,
                        0.02 + rng.nextDouble() * 0.08,
                        Math.sin(ang) * spd
                ));
            }
        }
    }

    private static final class BillParticle {
        double vx, vy, vz, px, py, pz;
        float yaw, vYaw;
        BillParticle(double vx, double vy, double vz, float yaw, float vYaw) {
            this.vx = vx; this.vy = vy; this.vz = vz; this.yaw = yaw; this.vYaw = vYaw;
        }
        void step() {
            px += vx; py += vy; pz += vz;
            vy -= 0.0028;
            yaw += vYaw;
        }
    }

    private static final class SparkParticle {
        double vx, vy, vz, px, py, pz;
        SparkParticle(double vx, double vy, double vz) {
            this.vx = vx; this.vy = vy; this.vz = vz;
        }
        void step() {
            px += vx; py += vy; pz += vz;
            vy -= 0.0022;
        }
    }

    private static final List<ActiveEffect> EFFECTS = new ArrayList<>();
    private static final Random RNG = new Random();

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(KillEffects::renderAll);
    }

    public static void spawnAt(double x, double y, double z) {
        BombowyConfig cfg = BombowyConfig.get();
        int type = class_3532.method_15340(cfg.killEffectType, 0, EFFECT_NAMES.length - 1);
        long now = System.currentTimeMillis();
        if (EFFECTS.size() >= 12) EFFECTS.remove(0);
        EFFECTS.add(new ActiveEffect(type, x, y, z, now, RNG));

        class_310 client = class_310.method_1551();
        if (cfg.killEffectSound && client.field_1687 != null && client.field_1724 != null) {
            switch (type) {
                case 0, 4 -> client.field_1687.method_43128(client.field_1724, x, y, z,
                        class_3417.field_14627, class_3419.field_15248, 1.0f, 1.35f);
                case 1 -> client.field_1687.method_43128(client.field_1724, x, y, z,
                        class_3417.field_14876, class_3419.field_15248, 1.2f, 0.85f);
                case 2 -> client.field_1687.method_43128(client.field_1724, x, y, z,
                        class_3417.field_14865, class_3419.field_15252, 1.1f, 1.05f);
                case 3 -> client.field_1687.method_43128(client.field_1724, x, y, z,
                        class_3417.field_15152.comp_349(), class_3419.field_15248, 0.7f, 1.25f);
            }
        }
    }

    private static void renderAll(WorldRenderContext ctx) {
        if (EFFECTS.isEmpty()) return;
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            EFFECTS.clear();
            return;
        }

        long now = System.currentTimeMillis();
        class_4587 matrices = ctx.matrixStack();
        if (matrices == null) return;
        class_4184 cam = ctx.camera();
        class_243 cPos = cam.method_19326();
        float scale = class_3532.method_15363(BombowyConfig.get().killEffectScale, 0.6f, 1.8f);

        class_4597.class_4598 immediate = client.method_22940().method_23000();
        class_327 tr = client.field_1772;

        Iterator<ActiveEffect> it = EFFECTS.iterator();
        while (it.hasNext()) {
            ActiveEffect ef = it.next();
            long age = now - ef.startMs;
            if (age > ef.durationMs) {
                it.remove();
                continue;
            }
            float t = age / (float) ef.durationMs;
            float alpha = 1.0f - class_3532.method_15363((t - 0.65f) / 0.35f, 0.0f, 1.0f);
            int aByte = class_3532.method_15340((int) (alpha * 255), 0, 255);

            for (BillParticle b : ef.bills) b.step();
            for (SparkParticle s : ef.sparks) s.step();

            if (ef.type == 0 || ef.type == 4) {
                boolean dollar = (ef.type == 0);
                int billColor = dollar ? ((aByte << 24) | 0x22C55E) : ((aByte << 24) | 0xFACC15);
                int borderColor = dollar ? ((aByte << 24) | 0x14532D) : ((aByte << 24) | 0xA16207);

                for (int i = 0; i < ef.bills.size(); i++) {
                    BillParticle b = ef.bills.get(i);
                    matrices.method_22903();
                    matrices.method_22904(ef.x + b.px - cPos.field_1352, ef.y + b.py - cPos.field_1351, ef.z + b.pz - cPos.field_1350);
                    matrices.method_22907(cam.method_23767());
                    matrices.method_22907(net.minecraft.class_7833.field_40718.rotationDegrees(b.yaw * 0.25f));
                    matrices.method_22905(0.022f * scale, -0.022f * scale, 0.022f * scale);
                    Matrix4f m = matrices.method_23760().method_23761();

                    int bw = dollar ? 18 : 10, bh = 10;
                    net.minecraft.class_332 dc = new net.minecraft.class_332(client, immediate);
                    dc.method_25294(-bw / 2 - 1, -bh / 2 - 1, bw / 2 + 1, bh / 2 + 1, borderColor);
                    dc.method_25294(-bw / 2, -bh / 2, bw / 2, bh / 2, billColor);
                    String sym = dollar ? "$" : "●";
                    tr.method_27522(class_2561.method_43470(sym), -tr.method_1727(sym) / 2.0f, -4.0f,
                            (aByte << 24) | 0xFFFFFF, false, m, immediate, class_327.class_6415.field_33993, 0, 0xF000F0);
                    matrices.method_22909();
                }
            } else if (ef.type == 1) {
                float dropY = 7.5f * (1.0f - class_3532.method_15363(t * 1.45f, 0.0f, 1.0f));
                matrices.method_22903();
                matrices.method_22904(ef.x - cPos.field_1352, ef.y + dropY - cPos.field_1351, ef.z - cPos.field_1350);
                matrices.method_22907(cam.method_23767());
                matrices.method_22905(0.045f * scale, -0.045f * scale, 0.045f * scale);
                Matrix4f m = matrices.method_23760().method_23761();
                net.minecraft.class_332 dc = new net.minecraft.class_332(client, immediate);
                dc.method_25294(-20, -10, 20, 10, (aByte << 24) | 0x334155);
                dc.method_25294(-14, -6, 14, 6, (aByte << 24) | 0x64748B);
                dc.method_25294(-4, -16, 4, -8, (aByte << 24) | 0x475569);
                tr.method_27522(class_2561.method_43470("SHARK!"), -tr.method_1727("SHARK!") / 2.0f, -4.0f,
                        (aByte << 24) | 0xF8FAFC, false, m, immediate, class_327.class_6415.field_33993, 0, 0xF000F0);
                matrices.method_22909();
            } else if (ef.type == 2) {
                class_4588 lines = immediate.getBuffer(class_1921.method_23594());
                matrices.method_22903();
                matrices.method_22904(ef.x - cPos.field_1352, ef.y - cPos.field_1351, ef.z - cPos.field_1350);
                var entry = matrices.method_23760();
                float[][] bolts = {
                        {0f, 12f, 0f, 0.35f * scale, 7.5f, 0.25f * scale},
                        {0.35f * scale, 7.5f, 0.25f * scale, -0.30f * scale, 3.8f, -0.20f * scale},
                        {-0.30f * scale, 3.8f, -0.20f * scale, 0f, 0f, 0f}
                };
                for (float[] seg : bolts) {
                    lines.method_56824(entry, seg[0], seg[1], seg[2]).method_22915(0.75f, 0.92f, 1.0f, alpha).method_60831(entry, 0f, 1f, 0f);
                    lines.method_56824(entry, seg[3], seg[4], seg[5]).method_22915(1.0f, 0.98f, 0.65f, alpha).method_60831(entry, 0f, 1f, 0f);
                }
                matrices.method_22909();
                immediate.method_22994(class_1921.method_23594());
            } else if (ef.type == 3) {
                for (SparkParticle s : ef.sparks) {
                    matrices.method_22903();
                    matrices.method_22904(ef.x + s.px - cPos.field_1352, ef.y + s.py - cPos.field_1351, ef.z + s.pz - cPos.field_1350);
                    matrices.method_22907(cam.method_23767());
                    matrices.method_22905(0.025f * scale, -0.025f * scale, 0.025f * scale);
                    net.minecraft.class_332 dc = new net.minecraft.class_332(client, immediate);
                    dc.method_25294(-3, -3, 3, 3, (aByte << 24) | 0xFF8C3B);
                    matrices.method_22909();
                }
            }
        }
        immediate.method_22993();
    }
}
