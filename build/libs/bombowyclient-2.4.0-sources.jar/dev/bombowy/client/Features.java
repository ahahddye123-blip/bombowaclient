package dev.bombowy.client;

import java.util.Map;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_4063;
import net.minecraft.class_4066;
import net.minecraft.class_5365;
import net.minecraft.class_7172;

public final class Features {
    private Features() {}

    private static Map<String, String> orig() {
        return BombowyConfig.get().orig;
    }

    private static <E extends Enum<E>> void en(String key, class_7172<E> opt, E val, boolean on, Class<E> cls) {
        if (on) {
            orig().putIfAbsent(key, opt.method_41753().name());
            opt.method_41748(val);
        } else {
            String s = orig().remove(key);
            if (s != null) {
                try { opt.method_41748(Enum.valueOf(cls, s)); } catch (Exception ignored) { }
            }
        }
    }

    private static void bool(String key, class_7172<Boolean> opt, boolean val, boolean on) {
        if (on) {
            orig().putIfAbsent(key, String.valueOf(opt.method_41753()));
            opt.method_41748(val);
        } else {
            String s = orig().remove(key);
            if (s != null) opt.method_41748(Boolean.parseBoolean(s));
        }
    }

    private static void num(String key, class_7172<Integer> opt, int val, boolean on, boolean asCap) {
        if (on) {
            orig().putIfAbsent(key, String.valueOf(opt.method_41753()));
            int cur = opt.method_41753();
            opt.method_41748(asCap ? Math.min(cur, val) : val);
        } else {
            String s = orig().remove(key);
            if (s != null) {
                try { opt.method_41748(Integer.parseInt(s)); } catch (Exception ignored) { }
            }
        }
    }

    private static void dbl(String key, class_7172<Double> opt, double val, boolean on) {
        if (on) {
            orig().putIfAbsent(key, String.valueOf(opt.method_41753()));
            opt.method_41748(val);
        } else {
            String s = orig().remove(key);
            if (s != null) {
                try { opt.method_41748(Double.parseDouble(s)); } catch (Exception ignored) { }
            }
        }
    }

    public static void fpsBoost(boolean on) {
        class_315 o = class_310.method_1551().field_1690;
        en("graphics", o.method_42534(), class_5365.field_25427, on, class_5365.class);
        en("particles", o.method_42475(), class_4066.field_18199, on, class_4066.class);
        en("clouds", o.method_42528(), class_4063.field_18162, on, class_4063.class);
        bool("shadows", o.method_42435(), false, on);
        bool("fps_ao", o.method_41792(), false, on);
    }

    public static void optimization(boolean on) {
        BombowyConfig cfg = BombowyConfig.get();
        class_315 o = class_310.method_1551().field_1690;
        en("opt_graphics", o.method_42534(), class_5365.field_25427, on, class_5365.class);
        en("opt_clouds", o.method_42528(), class_4063.field_18162, on, class_4063.class);
        bool("opt_shadows", o.method_42435(), false, on);
        bool("opt_ao", o.method_41792(), false, on);
        bool("opt_vsync", o.method_42433(), false, on);

        boolean potato = on && cfg.potatoMode;
        en("opt_particles", o.method_42475(), class_4066.field_18199, potato, class_4066.class);
        dbl("opt_entdist", o.method_42517(), 0.5, potato);
        num("opt_view", o.method_42503(), 8, potato, true);
        num("opt_sim", o.method_42510(), 5, potato, true);
        num("opt_mipmap", o.method_42563(), 0, potato, false);
        num("opt_blend", o.method_41805(), 0, potato, false);
        writeOptions();
    }

    public static void unlimitedFps(boolean on) {
        class_315 o = class_310.method_1551().field_1690;
        num("maxfps", o.method_42524(), 260, on, false);
        bool("vsync", o.method_42433(), false, on);
    }

    public static void entityDistance(boolean on) {
        class_315 o = class_310.method_1551().field_1690;
        dbl("entdist", o.method_42517(), 0.6, on);
    }

    public static void chunkCap(boolean on) {
        class_315 o = class_310.method_1551().field_1690;
        num("view", o.method_42503(), 12, on, true);
        num("sim", o.method_42510(), 8, on, true);
    }

    public static void quality(boolean on) {
        class_315 o = class_310.method_1551().field_1690;
        num("mipmap", o.method_42563(), 4, on, false);
        num("blend", o.method_41805(), 3, on, false);
    }

    public static void writeOptions() {
        class_310.method_1551().field_1690.method_1640();
    }
}
